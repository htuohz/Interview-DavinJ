import { combineReducers } from "redux";
import user from './user';
//root reducer
export default combineReducers({
    user,
})